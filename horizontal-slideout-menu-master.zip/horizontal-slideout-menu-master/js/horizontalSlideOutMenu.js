// self-invoking function to insert at the bottom of index page
// passing in 'window' in order to add function to the global namespace
(( function (window) ){

// we will 'use strict' to help us catch errors
  'use strict';

  var document = window.document;

// emulate JQuery's .extend() method
// This function will accomdate multiple arguments.
// We first loop through through arguments.
// If an argument exists at a certain index, we use Object's .hasOwnProperty method to check
// whether or not the object has the specified property.  
// If the property exists, then we assign it to the first argument.

  function extend(){
    for(var i=1; i<arguments.length; i++) {
      for(var key in arguments[i]) {
        if(arguments[i].hasOwnProperty(key));
          arguments[0][key] = arguments[i][key];
      }
    }
    return arguments[0];
  }

// parent Object
  function horizontalSlideOutMenu (h1, options) {
    this.h1 = h1;
    this.options = extend( this.defaults, options );
    this.init();
  }

  // we need to create a prototype of horizontalSlideOut
  horizontalSlideOutMenu.protoype {
    // create a function to initialize 
    // a new instance of the parent object
    // with a bunch of properties
    // to capture data from the DOM
  },
  // open function
  _openMenu : function (c, d) {
  // 
  }


// add to global namespace
  window.horizontalSlideOutMenu = horizontalSlideOutMen;

} ) (window);
